const UsersList = [{
        id: 1,
        name: 'zhangsan',
        sex: "male",
        age: 20,
        totalAmount: 6000
    },
    {
        id: 2,
        name: 'lisi',
        sex: "female",
        age: 20,
        totalAmount: 60000
    },
    {
        id: 3,
        name: 'wangwu',
        sex: "male",
        age: 20,
        totalAmount: 12010
    },
    {
        id: 4,
        name: "maliu",
        sex: "male",
        age: 20,
        totalAmount: 450
    }
];

module.exports = UsersList;